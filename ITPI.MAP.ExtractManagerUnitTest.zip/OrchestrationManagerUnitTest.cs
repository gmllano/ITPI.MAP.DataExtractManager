﻿using Moq;
using ITPI.MAP.DataExtractManager;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace ITPI.MAP.ExtractManagerUnitTest
{
	[TestClass]
	public class OrchestrationManagerUnitTest
	{
		[TestMethod]
		public void CheckEmptyFilePathString()
		{
			// Arrange.
			var sectionsExtract = new SectionsExtract();
			int courseCnt = 0;
			string sourcePath = string.Empty;
			var dataManager = new Mock<IDataManager>(MockBehavior.Strict);
			var semesterResult = dataManager.Setup(a => a.GetSemesters()).Returns(new List<Semesters>());
			var insertResult = dataManager.Setup(a => a.InsertSectionsExtract(sectionsExtract, ref courseCnt)).Returns(true);
			var logger = new Mock<ILogger>();

			// Act
			var orchManager = new OrchestrationManager(sourcePath, dataManager.Object, logger.Object);
			orchManager.GetFiles();

			// Assert.
			logger.Verify(l => l.Error("Source path is missing."));
		}

		[TestMethod]
		public void CheckInvalidDirectoryPath()
		{
			// Arrange.
			var sectionsExtract = new SectionsExtract();
			int courseCnt = 0;
			string sourcePath = @"C:\XYZ\";
			var dataManager = new Mock<IDataManager>(MockBehavior.Strict);
			var semesterResult = dataManager.Setup(a => a.GetSemesters()).Returns(new List<Semesters>());
			var insertResult = dataManager.Setup(a => a.InsertSectionsExtract(sectionsExtract, ref courseCnt)).Returns(true);
			var logger = new Mock<ILogger>();

			// Act
			var orchManager = new OrchestrationManager(sourcePath, dataManager.Object, logger.Object);
			orchManager.GetFiles();

			// Assert.
			logger.Verify(l => l.Error("Directory does not exists."));
		}

		// TODO: More tests needed.
	}
}
